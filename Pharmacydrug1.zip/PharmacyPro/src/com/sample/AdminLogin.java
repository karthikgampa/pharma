package com.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		HttpSession session = request.getSession();
		
		String usname = request.getParameter("uname");
		String pass = request.getParameter("pass");
		if(usname.equals("Pharmacy") && pass.equals("pharmacy"))
		{
			session.setAttribute("adminName", usname);
			RequestDispatcher rd = request.getRequestDispatcher("AdminHome.html");
			rd.forward(request, response);
		}
		else
		{
			pw.println("<html><head>");
			pw.println("<meta http-equiv='refresh' content='0.5;URL=AdminLogin.html'>");
			pw.println("<body onload='myFunction()'>");
			pw.println("<script>");
			pw.println("function myFunction()");
			pw.println("{");
			pw.println(" alert('Login Failed...!!');");
			pw.println("}");
			pw.println("</script></head></html>");
		}
	}

}
