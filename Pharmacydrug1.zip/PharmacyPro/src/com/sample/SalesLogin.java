package com.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SalesLogin
 */
@WebServlet("/SalesLogin")
public class SalesLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalesLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		ServletContext sc = getServletContext();
		String url = sc.getInitParameter("url");
		String usname = sc.getInitParameter("username");
		String pass = sc.getInitParameter("password");
		HttpSession session = request.getSession();
		
		String uname = request.getParameter("uname");
		session.setAttribute("adminName", uname);
		String password = request.getParameter("pass");
		String cpass = null;
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,usname,pass);
			PreparedStatement ps = con.prepareStatement("select password from salespasswords where username=?");
			ps.setString(1, uname);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
			    cpass = rs.getString(1);
			}
			if(cpass==null){
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesLogin.html'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Invalid Username...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
			else if(cpass.equals(password))
			{
				RequestDispatcher rd = request.getRequestDispatcher("SalesHome.html");
				rd.forward(request, response);
			}
			else
			{
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesLogin.html'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Login Failed...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
					
		
	}

}
