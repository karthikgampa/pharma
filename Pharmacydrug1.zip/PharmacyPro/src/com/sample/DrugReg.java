package com.sample;

import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DrugReg
 */
@WebServlet("/DrugReg")
public class DrugReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DrugReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		ServletContext sc = getServletContext();
		String url = sc.getInitParameter("url");
		String usname = sc.getInitParameter("username");
		String pass = sc.getInitParameter("password");
		
		String name = request.getParameter("name");
		float cost = Float.parseFloat(request.getParameter("cost"));
		int quan = Integer.parseInt(request.getParameter("quan"));
		String md1 = request.getParameter("man_d");
		String mdarr[] = new String[3];
		mdarr = md1.split("-");
		String md = mdarr[2] + "-" + mdarr[1] + "-" + mdarr[0];
		
		String ed1 = request.getParameter("exp_d");
		String edarr[] = new String[3];
		edarr = ed1.split("-");
		String ed = edarr[2] + "-" + edarr[1] + "-" + edarr[0];
		
		String rd1 = request.getParameter("reg_d");
		String rdarr[] = new String[3];
		rdarr = rd1.split("-");
		String rd = rdarr[2] + "-" + rdarr[1] + "-" + rdarr[0];
		int rack = Integer.parseInt(request.getParameter("rack"));
		String m_loc = request.getParameter("man_loc");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,usname,pass);
			PreparedStatement ps = con.prepareStatement("insert into drugs values(d_id.nextval,?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
			ps.setString(1,name);
			ps.setFloat(2,cost);
			ps.setInt(3,quan);
			ps.setString(4,md);
			ps.setString(5,ed);
			ps.setString(6,rd);
			ps.setInt(7, rack);
			ps.setString(8, m_loc);
			int rs = ps.executeUpdate();
			if(rs>0)
			{
				System.out.println("Added Successfull!!");
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Registered Successfully...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
			else
			{
				System.out.println("not added");
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Registration Failed...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	}
