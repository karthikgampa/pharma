package com.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		ServletContext sc = getServletContext();
		String url = sc.getInitParameter("url");
		String uname = sc.getInitParameter("username");
		String pass = sc.getInitParameter("password");
		
		int id = Integer.parseInt(request.getParameter("id"));
		String col = request.getParameter("col");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,uname,pass);
			PreparedStatement ps = null;
			switch(col)
			{
			case "name": ps = con.prepareStatement("update drugs set name=? where id=?");
			break;
			case "cost": ps = con.prepareStatement("update drugs set cost=? where id=?");
			break;
			case "quantity": ps = con.prepareStatement("update drugs set quantity=? where id=?");
			break;
			case "man_date": ps = con.prepareStatement("update drugs set man_date=? where id=?");
			break;
			case "exp_date": ps = con.prepareStatement("update drugs set exp_date=? where id=?");
			break;
			case "reg_date": ps = con.prepareStatement("update drugs set reg_date=? where id=?");
			break;
			case "rack": ps = con.prepareStatement("update drugs set rack=? where id=?");
			break;
			case "man_loc": ps = con.prepareStatement("update drugs set man_loc=? where id=?");
			break;
			}
			if(col.equals("quantity") || col.equals("rack"))
			{
				int value = Integer.parseInt(request.getParameter("value"));
				//System.out.println(column);
				ps.setInt(1,value);
			}
			else if(col.equals("cost"))
			{
				float value = Float.parseFloat(request.getParameter("value"));
				//System.out.println(column);
				ps.setFloat(1, value);
			}
			else
			{
				String value = request.getParameter("value");
				System.out.println(value);
				ps.setString(1, value);
			}
			ps.setInt(2, id);
			int rs = ps.executeUpdate();
			if(rs>0)
			{
				pw.println("<html>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Updated Successfully...!!');");
				pw.println("}");
				pw.println("</script></html>");
			}
			else
			{
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Updation Failed...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
