package com.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SalesRegister
 */
@WebServlet("/SalesRegister")
public class SalesRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SalesRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		ServletContext sc = getServletContext();
		String url = sc.getInitParameter("url");
		String usname = sc.getInitParameter("username");
		String pass = sc.getInitParameter("password");
		
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String uname = request.getParameter("uname");
		String password = request.getParameter("pass");
		String cpassword = request.getParameter("conpass");
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,usname,pass);
			PreparedStatement ps = con.prepareStatement("select username from salespasswords");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				if(uname.equals(rs.getString(1))){
					pw.println("<html><head>");
					pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesRegister.html'>");
					pw.println("<body onload='myFunction()'>");
					pw.println("<script>");
					pw.println("function myFunction()");
					pw.println("{");
					pw.println(" alert('Username already exists...Please try again!!');");
					pw.println("}");
					pw.println("</script></head></html>");
				}
			}
			if(cpassword.equals(password)){
				PreparedStatement ps1 = con.prepareStatement("insert into salespasswords values(?,?,?,?)");
				ps1.setString(1,fname);
				ps1.setString(2, lname);
				ps1.setString(3, uname);
				ps1.setString(4, password);
				int rs1 = ps1.executeUpdate();
				if(rs1>0){
					System.out.println("Added Successfull!!");
					pw.println("<html><head>");
					pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesLogin.html'>");
					pw.println("<body onload='myFunction()'>");
					pw.println("<script>");
					pw.println("function myFunction()");
					pw.println("{");
					pw.println(" alert('Registered Successfully...!!');");
					pw.println("}");
					pw.println("</script></head></html>");
				}
				else
				{
					System.out.println("not added");
					pw.println("<html><head>");
					pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesLogin.html'>");
					pw.println("<body onload='myFunction()'>");
					pw.println("<script>");
					pw.println("function myFunction()");
					pw.println("{");
					pw.println(" alert('Registration Failed...!!');");
					pw.println("}");
					pw.println("</script></head></html>");
				}
			}
			else{
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=SalesRegister.html'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Passwords not matched...!! Please try again');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
