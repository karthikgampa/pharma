package com.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		ServletContext sc = getServletContext();
		String url = sc.getInitParameter("url");
		String uname = sc.getInitParameter("username");
		String password = sc.getInitParameter("password");
		
		int id = Integer.parseInt(request.getParameter("id"));
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url,uname,password);
			PreparedStatement ps = con.prepareStatement("delete from drugs where id=?");
			ps.setInt(1,id);
			int rs = ps.executeUpdate();
			if(rs>0)
			{
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Deleted Successfully...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
				//RequestDispatcher rd2 = request.getRequestDispatcher("AdminHome.html");
				//rd2.forward(request, response);
				//response.sendRedirect("AdminHome.html");
			}
			else
			{
				pw.println("<html><head>");
				pw.println("<meta http-equiv='refresh' content='0.5;URL=ViewDrugs.jsp'>");
				pw.println("<body onload='myFunction()'>");
				pw.println("<script>");
				pw.println("function myFunction()");
				pw.println("{");
				pw.println(" alert('Deletion Failed...!!');");
				pw.println("}");
				pw.println("</script></head></html>");
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
